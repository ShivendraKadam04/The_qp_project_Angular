export const environment = {
    production: true,
    apiUrl: 'http://46.202.190.84:8001/api',
    firebase: {
      apiKey: "AIzaSyAL1AmIeGk6Cxt-47o2j_l99bhmIubsaKk",
  authDomain: "the-quran-project.firebaseapp.com",
  projectId: "the-quran-project",
  storageBucket: "the-quran-project.firebasestorage.app",
  messagingSenderId: "408869748204",
  appId: "1:408869748204:web:ef62bce8deb5de12d1d4c9",
    measurementId: "G-F6FZW93BH5"
    }
  };
  
  // export const environment = {
  //   production: true,
  //   apiUrl: '/api',
  //   firebase: {
  //     apiKey: "AIzaSyAL1AmIeGk6Cxt-47o2j_l99bhmIubsaKk",
  // authDomain: "the-quran-project.firebaseapp.com",
  // projectId: "the-quran-project",
  // storageBucket: "the-quran-project.firebasestorage.app",
  // messagingSenderId: "408869748204",
  // appId: "1:408869748204:web:ef62bce8deb5de12d1d4c9",
  //   measurementId: "G-F6FZW93BH5"
  //   }
  // };